<?php

if (!empty($mission)) {
?>
  <div id="mission" class="og-mission"><?php print $mission; ?></div>
<?php } ?>